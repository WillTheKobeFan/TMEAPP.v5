// app/(tabs)/_layout.tsx

import { Tabs } from "expo-router";

import CustomNavBarV3 from "src/components/navigation/CustomNavBarV3";

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
      }}
      tabBar={(props) => <CustomNavBarV3 {...props} />}
    >
      {/* Page 1 */}
      <Tabs.Screen name="home" />
      <Tabs.Screen name="schedule" />
      <Tabs.Screen name="standings" />
      <Tabs.Screen name="inbox" />
      <Tabs.Screen name="myhub" />

      {/* Page 2 */}
      <Tabs.Screen name="champs" />
      <Tabs.Screen name="progression" />
      <Tabs.Screen name="search" />
      <Tabs.Screen name="settings" />
    </Tabs>
  );
}