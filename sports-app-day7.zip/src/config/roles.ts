// src/config/roles.ts

/**
 * Every role supported across organizations.
 *
 * Keep these IDs stable because they may eventually be stored in:
 * - Firestore membership documents
 * - Organization configurations
 * - User filters
 * - Permission rules
 */
export const ROLE_IDS = {
  ADMIN: "admin",
  CAPTAIN: "captain",
  PLAYER: "player",
  REFEREE: "referee",
  SCOREKEEPER: "scorekeeper",
  COACH: "coach",
  FACILITY: "facility",
} as const;

/**
 * Creates a union type from ROLE_IDS.
 *
 * Result:
 * "admin"
 * | "captain"
 * | "player"
 * | "referee"
 * | "scorekeeper"
 * | "coach"
 * | "facility"
 */
export type RoleId = (typeof ROLE_IDS)[keyof typeof ROLE_IDS];

/**
 * Broad role categories used for:
 * - Filtering
 * - Organization setup
 * - Grouped permission management
 * - Admin-panel display
 */
export const ROLE_CATEGORY_IDS = {
  MANAGEMENT: "management",
  PARTICIPANT: "participant",
  OFFICIAL: "official",
  DEVELOPMENT: "development",
  OPERATIONS: "operations",
} as const;

export type RoleCategoryId =
  (typeof ROLE_CATEGORY_IDS)[keyof typeof ROLE_CATEGORY_IDS];

/**
 * Shape of a role displayed or used throughout the app.
 */
export type RoleDefinition = {
  id: RoleId;
  label: string;
  shortLabel: string;
  description: string;
  category: RoleCategoryId;
  organizationAssignable: boolean;
};

/**
 * Universal role definitions.
 *
 * Organizations can enable or disable these roles, but the IDs
 * remain consistent throughout the entire app.
 */
export const ROLES: Record<RoleId, RoleDefinition> = {
  [ROLE_IDS.ADMIN]: {
    id: ROLE_IDS.ADMIN,
    label: "Admin / Director",
    shortLabel: "Admin",
    description:
      "Manages the organization, programs, users, schedules, communication, and settings.",
    category: ROLE_CATEGORY_IDS.MANAGEMENT,
    organizationAssignable: true,
  },

  [ROLE_IDS.CAPTAIN]: {
    id: ROLE_IDS.CAPTAIN,
    label: "Captain",
    shortLabel: "Captain",
    description:
      "Represents a team and may receive team-specific updates, responsibilities, and tools.",
    category: ROLE_CATEGORY_IDS.PARTICIPANT,
    organizationAssignable: true,
  },

  [ROLE_IDS.PLAYER]: {
    id: ROLE_IDS.PLAYER,
    label: "Player / Participant",
    shortLabel: "Player",
    description:
      "Participates in leagues, games, camps, clinics, training, or other organization programs.",
    category: ROLE_CATEGORY_IDS.PARTICIPANT,
    organizationAssignable: true,
  },

  [ROLE_IDS.REFEREE]: {
    id: ROLE_IDS.REFEREE,
    label: "Referee / Official",
    shortLabel: "Referee",
    description:
      "Views assigned games, officiating schedules, organization updates, and relevant resources.",
    category: ROLE_CATEGORY_IDS.OFFICIAL,
    organizationAssignable: true,
  },

  [ROLE_IDS.SCOREKEEPER]: {
    id: ROLE_IDS.SCOREKEEPER,
    label: "Scorekeeper",
    shortLabel: "Scorekeeper",
    description:
      "Views assigned games and may record scores, results, and other game information.",
    category: ROLE_CATEGORY_IDS.OFFICIAL,
    organizationAssignable: true,
  },

  [ROLE_IDS.COACH]: {
    id: ROLE_IDS.COACH,
    label: "Coach / Trainer",
    shortLabel: "Coach",
    description:
      "Supports teams or participants through coaching, instruction, clinics, camps, or training.",
    category: ROLE_CATEGORY_IDS.DEVELOPMENT,
    organizationAssignable: true,
  },

  [ROLE_IDS.FACILITY]: {
    id: ROLE_IDS.FACILITY,
    label: "Facility Operations",
    shortLabel: "Facility",
    description:
      "Supports locations, courts, fields, equipment, access, and other operational responsibilities.",
    category: ROLE_CATEGORY_IDS.OPERATIONS,
    organizationAssignable: true,
  },
};

/**
 * Array version for:
 * - FlatList
 * - Dropdowns
 * - Setup wizard options
 * - Admin-panel role selectors
 */
export const ROLE_LIST: RoleDefinition[] = Object.values(ROLES);

/**
 * Returns a complete role definition.
 */
export function getRoleById(roleId: RoleId): RoleDefinition {
  return ROLES[roleId];
}

/**
 * Checks whether an unknown value is a valid RoleId.
 *
 * Useful when reading role data from Firestore, route parameters,
 * forms, or imported organization data.
 */
export function isRoleId(value: unknown): value is RoleId {
  return (
    typeof value === "string" &&
    Object.values(ROLE_IDS).includes(value as RoleId)
  );
}

/**
 * Returns only valid roles from an unknown array.
 *
 * This prevents invalid or outdated Firestore values from reaching
 * the rest of the application.
 */
export function sanitizeRoleIds(values: unknown): RoleId[] {
  if (!Array.isArray(values)) {
    return [];
  }

  return [...new Set(values.filter(isRoleId))];
}

/**
 * Checks whether a user has a particular role.
 */
export function hasRole(
  userRoles: readonly RoleId[],
  requiredRole: RoleId
): boolean {
  return userRoles.includes(requiredRole);
}

/**
 * Checks whether a user has at least one role from a supplied list.
 */
export function hasAnyRole(
  userRoles: readonly RoleId[],
  requiredRoles: readonly RoleId[]
): boolean {
  return requiredRoles.some((roleId) => userRoles.includes(roleId));
}

/**
 * Checks whether a user has every role from a supplied list.
 */
export function hasAllRoles(
  userRoles: readonly RoleId[],
  requiredRoles: readonly RoleId[]
): boolean {
  return requiredRoles.every((roleId) => userRoles.includes(roleId));
}

/**
 * Convenience helper for administrative access.
 */
export function isAdmin(userRoles: readonly RoleId[]): boolean {
  return hasRole(userRoles, ROLE_IDS.ADMIN);
}

/**
 * Groups roles by category for setup and admin screens.
 */
export function getRolesByCategory(
  category: RoleCategoryId
): RoleDefinition[] {
  return ROLE_LIST.filter((role) => role.category === category);
}